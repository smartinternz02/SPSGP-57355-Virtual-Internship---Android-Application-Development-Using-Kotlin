---
name: 'Android Basics: Dogglers app'
about: Describe this issue template's purpose here.
title: 'Android Basics: Dogglers app'
labels: ''
assignees: ''

---

**URL of codelab**


**In which task and step of the codelab can this issue be found?**


**Describe the problem**




**Steps to reproduce?**
1. Go to...
2. Click on...
3. See error...

**Versions**
_Android Studio version:_ 
_API version of the emulator:_ 


**Additional information**
_Include screenshots if they would be useful in clarifying the problem._
