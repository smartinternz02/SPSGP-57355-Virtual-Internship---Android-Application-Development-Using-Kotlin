# Lunch Tray

This is the independent project for [Unit 3] of [Android Basics in Kotlin] course from Google, see the [Lunch Tray Codelab].

[Android Basics in Kotlin]: https://developer.android.com/courses/android-basics-kotlin/course
[Unit 3]: https://developer.android.com/courses/android-basics-kotlin/unit-3
[Lunch Tray Codelab]: https://developer.android.com/codelabs/basic-android-kotlin-training-project-lemonade

----

Environment

- Kotlin 1.7.10
- Android Studio Chipmunk 2021.2.1
- Gradle Plugin 7.2.2

----

updated: 2022-08-20